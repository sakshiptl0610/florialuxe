<footer class="footer">
    <div class="footer-container">

        <div class="footer-left">
            <a href="#"><img src="<?= base_url() ?>assets/icons/FLORIA-CONTACT ICON-2.svg" alt=""></a>
            <a href="#"><img src="<?= base_url() ?>assets/icons/FLORIA-CONTACT ICON-3.svg" alt=""></a>
            <a href="#"><img src="<?= base_url() ?>assets/icons/FLORIA-CONTACT ICON-4.svg" alt=""></a>
        </div>

        <div class="footer-right">
             <a href="<?php echo base_url('home'); ?>">
            <img src="<?= base_url() ?>assets/logo/footer-logo.svg" class="footer-logo" alt="Floria Luxe Logo">
            </a>
        </div>

    </div>
</footer>